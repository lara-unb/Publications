package nowifichallengetester;

public interface ConnectionChangedListener {
    void onConnectionChanged();
}
